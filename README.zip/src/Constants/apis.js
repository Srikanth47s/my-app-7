const CONFIG = {
    BASE_URL: 'https://api.softwareschool.co',
    TIME_OUT: 15000,
    AUTHORIZATION:'authorization',
    TOKEN: 'token',
    BEARER: 'Bearer'
}

export default CONFIG;