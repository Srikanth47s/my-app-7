export function Footer(){
    return(
        <div>
            From footer
        </div>
    )
}