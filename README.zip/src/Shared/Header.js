import { checkUserLogin } from "../Utils/util"

export function Header() {

    let userLogin = checkUserLogin();

    let handleLogout = () => {
        let userNum = localStorage.getItem('userNum');
        localStorage.clear();
        localStorage.setItem('userNum',userNum)
        window.location = '/';
    }

    return (
        <nav className="navbar navbar-expand-lg bg-body-tertiary">
            <div className="container">
                <a className="navbar-brand">Amazon</a>
                <div className="d-flex">
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <a className="nav-link" href="/">Home</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="/price">Price</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="/contact">Contact</a>
                        </li>
                    </ul>
                    <div>

                        <div className="dropdown">
                            <button className="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Hello, user <span className="fw-bold">Account</span>
                            </button>
                            {
                                userLogin == false &&
                                <ul className="dropdown-menu">
                                    <li><a className="dropdown-item" href="/login">Login</a></li>
                                    <li><a className="dropdown-item" href="/signup">New customer? <span className="text-primary">Start here.</span></a></li>
                                </ul>
                            }
                            {
                                userLogin == true &&
                                <ul className="dropdown-menu">
                                    <li><a className="dropdown-item" onClick={e => handleLogout()}>Logout</a></li>
                                </ul>
                            }

                        </div>

                    </div>
                </div>

            </div>
        </nav>
    )
}