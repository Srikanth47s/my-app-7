export function Login() {

 


    return (
        <div>
            <button className="btn btn-primary">Login</button>
            
        </div>

    )
}