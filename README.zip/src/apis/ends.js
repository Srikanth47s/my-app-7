const ENDS_URL = {
    LOG_IN: '',
    SIGN_UP: '/auth/signup',
    FORGOT_PASSWORD: ''
}

export default ENDS_URL;