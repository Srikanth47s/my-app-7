import { Footer } from "./Shared/Footer";
import { Header } from "./Shared/Header";

export function Home(){
    return(
        <div>
            <Header />
            <div>
                Home page
            </div>
            <Footer />
        </div>
    )
}